=========
Changelog
=========

For the most recent changes to the Python Progressbar please look at the Git
releases or the commit log:

 - https://github.com/WoLpH/python-progressbar/releases
 - https://github.com/WoLpH/python-progressbar/commits/develop

Hint: click on the `...` button to see the change message.
